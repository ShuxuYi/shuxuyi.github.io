/** Automatically generated file. DO NOT MODIFY */
package com.ThePSRMaster_Astro;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}