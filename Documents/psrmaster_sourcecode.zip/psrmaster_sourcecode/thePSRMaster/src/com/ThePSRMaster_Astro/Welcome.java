package com.ThePSRMaster_Astro;

import com.ThePSRMaster_Astro.R;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class Welcome extends Activity {
			@Override
			protected void onCreate(Bundle savedInstanceState) {
			super.onCreate(savedInstanceState);
			//Button buttonw1;
			//Button buttonw2;
			setContentView(R.layout.welcome_layout);
			Button buttonw1 = (Button) findViewById(R.id.button1);
			Button buttonw2 = (Button) findViewById(R.id.button2);
			Button buttonw3 = (Button) findViewById(R.id.button3);
			buttonw1.setOnClickListener(new OnClickListener() {            
				         public void onClick(View v) {
				             startActivity(new Intent(getApplicationContext(), Selection.class));
				         }
				     });
			
			buttonw2.setOnClickListener(new OnClickListener() {            
		         public void onClick(View v) {
		             startActivity(new Intent(getApplicationContext(), Introduction.class));
		         }
		     });
			buttonw3.setOnClickListener(new OnClickListener() {            
		         public void onClick(View v) {
		             startActivity(new Intent(getApplicationContext(), Advisor.class));
		         }
		     });
			}
}
