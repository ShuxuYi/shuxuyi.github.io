package com.ThePSRMaster_Astro;

import java.util.Random;
import java.util.Timer;

import com.ThePSRMaster_Astro.R;
//import com.example.PSRmater.MainActivity.ButtonListener;

import android.app.Activity;
//import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.format.Time;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;


public class Advisor extends Activity {
	public int tough=0;
	public int diaosi=0;//1˵�����ǌ�˿��-1˵��������ǌ�˿
	public ImageButton btnscissor;
	public ImageButton btnrock;
	public ImageButton btnpaper;
	public ImageView robotwhat;
	public TextView Total;//2
	public TextView Wins;//5
	public TextView Losses;//8
	public TextView Ties;//11
	public TextView first;
	public TextView second;
	public TextView third;
	public TextView forth;
	public TextView fifth;
	public TextView sixth;
	public TextView seventh;
	public TextView eighth;
	public TextView nineth;
	public TextView tenth;
	

	public int mydecision=0;//0,1,2 the computer's decision 0,1,2
	public int youmoved=0;//0 haven't move, 1 moved. it should be turn to 0 at beginning of each round. 
	public int yourdecision=0;//the player's decision 0,1,2
	public int foolishness=1;//������Ĵ�ɵ�ӵȼ�
	public int strategy[][]={{1,0,2},{2,2,2},{0,2,1},{1,1,1},{2,1,0},{0,0,0}};
	public int result=0;//tie 0; 1, computer win; 2, player win
	public int lianbai=0;
	public int liansheng=0;
	public int numofwin=0;
	public int numofloss=0;
	public int numoftie=0;
	//public int wozhong=0;
	//public int nizhong=0;
	public int wise=0;
	public int rotate=0;
	public int previous=0;//player's previous move.
	public int[] rotation=new int[8];
	public int correlation=0;
	public int pattern=0;
	public int Iguess=0;
	public int k=0;
	public int best=3;
	public int i=1;
	//public boolean userpress=true;
	public int period=0;//this is the period of the pattern.
	public int disapper=0;//this is a flag of the disappear of the pattern.
	public int[] shift=new int[8];
	Timer timer=new Timer();
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		setContentView(R.layout.advisemode);
		btnscissor=(ImageButton)findViewById(R.id.imageButton1);
		btnrock=(ImageButton)findViewById(R.id.imageButton3);
		btnpaper=(ImageButton)findViewById(R.id.imageButton2);
		robotwhat=(ImageView)findViewById(R.id.imageView1);
		Total=(TextView)findViewById(R.id.textView2);
		Wins=(TextView)findViewById(R.id.textView5);
		Losses=(TextView)findViewById(R.id.textView8);
		Ties=(TextView)findViewById(R.id.textView11);
		first=(TextView)findViewById(R.id.textView1);
		second=(TextView)findViewById(R.id.textView3);
		third=(TextView)findViewById(R.id.textView4);
		forth=(TextView)findViewById(R.id.textView6);
		fifth=(TextView)findViewById(R.id.textView7);
		sixth=(TextView)findViewById(R.id.textView9);
		seventh=(TextView)findViewById(R.id.textView10);
		eighth=(TextView)findViewById(R.id.textView12);
		nineth=(TextView)findViewById(R.id.textView13);
		tenth=(TextView)findViewById(R.id.textView14);
		first.setTextColor(Color.argb(255,0,200,200));
		second.setTextColor(Color.argb(255,0,200,200));
		third.setTextColor(Color.argb(255,0,200,200));
		forth.setTextColor(Color.argb(255,0,200,200));
		fifth.setTextColor(Color.argb(255,0,200,200));
		sixth.setTextColor(Color.argb(255,0,200,200));
		seventh.setTextColor(Color.argb(255,0,200,200));
		eighth.setTextColor(Color.argb(255,0,200,200));
		nineth.setTextColor(Color.argb(255,0,200,200));
		tenth.setTextColor(Color.argb(255,0,200,200));
		Wins.setTextColor(Color.argb(255,255,0,0));
		Losses.setTextColor(Color.argb(255,0,255,0));
		Ties.setTextColor(Color.argb(255, 0, 0, 255));
		Total.setTextColor(Color.argb(255,0,200,200));
		
		
		
		ButtonListener btnDoListener=new ButtonListener();
		btnscissor.setOnClickListener(btnDoListener);
		btnrock.setOnClickListener(btnDoListener);
		btnpaper.setOnClickListener(btnDoListener);
		
		computersmove(i);
		
		
		
		
	}
	public boolean computersmove(int i){
		Time time=new Time();
		Random random=new Random();
		if (i==1) {time.setToNow();mydecision=time.second%3;} 
		else if (i<=4 && i>1) {if (result==1) mydecision=(mydecision-1+3)%3;else mydecision=(mydecision-1+3)%3;}
			//mydecision=random.nextInt(3);//initial move is random, from 0 to 2.
		else if(pattern==1);
		else switch (wise){
		case 0:{mydecision=(mydecision+strategy[foolishness][result])%3;break;}
		case 1:{if(tough==0) mydecision=random.nextInt(3); else mydecision=(mydecision+strategy[foolishness][result]+2)%3; break;}
		case 2:{mydecision=(mydecision+strategy[foolishness][result])%3;break;}
		default:break;
		}
		
		//looking for periodic structure
		if (i<8) rotation[i]=rotate-1;//this minus one is important, to make rotation=-1,0,1
		else {for (int l=0;l<=6;l++) {rotation[l]=rotation[l+1];} rotation[7]=rotate-1;}//moving window
		k=0;
		correlation=0;
		best=3;
		while (k<=4) {k++;correlation=0;
	   	for (int j=0;j<=7-k;j++){shift[j]=rotation[k+j];
		}
		for (int j=1;j<=k;j++){shift[7-k+j]=rotation[7-k+j];
		}
		for (int l=0;l<8;l++) {//cout<<rotation[l]<<"*"<<shift[l]<<endl;
			correlation+=rotation[l]*shift[l];
			}
		     // cout<<"k="<<k<<" correlation="<<correlation<<endl;
		if (correlation>best) {best=correlation;period=k;}
		else;
				}

		if (best>3) {pattern=1;foolishness=-1;}//cout<<"correlation="<<correlation<<endl;}
		else pattern=0;
		if (pattern==1) {Iguess=rotation[8-period]+1;mydecision=(3-previous-Iguess+1)%3;}//this plus 1 is crucial
		else;
		if (diaosi==1) {time.setToNow();mydecision=time.second%3;}//if you loss too much, then use random!!
		else;
	//unveil the computer's decision			
		
			switch (mydecision){
			case 0:{robotwhat.setImageResource(R.drawable.paper_trans);break;}
			case 1:{robotwhat.setImageResource(R.drawable.scissor_transp);break;}
			case 2:{robotwhat.setImageResource(R.drawable.rock_transp);break;}
			}
		
		
	///////my decision is over//////////////////////////////
		return false;
		}//end of the function "thecomputer's move"
	
	public boolean resultevalue(int mydecision,int yourdecision){

		rotate=(3+yourdecision-previous)%3;
		result=(mydecision+yourdecision+3)%3; 
			//txt.setText(String.valueOf(result));
		
		switch (result){//judge from previous result;
			case 0 : {switch (rotate){
					case 0 : {foolishness=0;break;}
					case 1 : {foolishness=2;break;}
					case 2 : {foolishness=1;break;}
					default : break;};break;}
			case 1 : {switch (rotate){
	                        case 0 : {foolishness=5;break;}
	                        case 1 : {foolishness=1;break;}
	                        case 2 : {foolishness=3;break;}
	                        default : break;};break;}
			case 2 : {switch (rotate){
	                        case 0 : {foolishness=1;break;}
	                        case 1 : {foolishness=2;break;}
	                        case 2 : {foolishness=4;break;}
	                        default : break;};break;}
			default:break;}//end of switch
		

	//pattern recognise  or mymove given here
	//	
		//cout<<"rotation="<<rotate-1<<endl;
		previous=yourdecision;

		if ((pattern==1)&&(result!=1)) {for (int j=0;j<=7;j++) rotation[j]=0; pattern=0;period=0;} //pattern disappear;
		else ;
		switch (result){
		case 0:{lianbai=0;liansheng=0;numoftie++;break;}
		
		case 1:{lianbai=0;liansheng++;numofwin++;break;}
		//case -2:{txt.setText("��Ӯ�ˣ���̫����");myscore++;break;}
		case 2:{lianbai++;liansheng=0;numofloss++;break;}
		//case -1:{txt.setText("��Ӯ�ˣ��ɵĺã�");yourscore++;break;}
		default : break;}
	
		Wins.setText(String.valueOf(numofwin));
	
		Losses.setText(String.valueOf(numofloss));

		Ties.setText(String.valueOf(numoftie));
		
		Total.setText(String.valueOf(i));

		if (numofloss-numofwin>10) diaosi=1;
		else diaosi=0;
	//���ݲ�ͬ�ĵ���ѡ��ͬ��ģʽ

		return false;
		}

	class ButtonListener implements OnClickListener{
		public  void onClick(View v){
		
			switch (v.getId()){
				case R.id.imageButton1:{i++;yourdecision=2;break;}
				case R.id.imageButton3:{i++;yourdecision=1;break;}
				case R.id.imageButton2:{i++;yourdecision=0;break;}
				default: break;}
		//	if(youmoved==0){
			resultevalue(mydecision,yourdecision);
			computersmove(i);
			
			}
		}
	
		
}
