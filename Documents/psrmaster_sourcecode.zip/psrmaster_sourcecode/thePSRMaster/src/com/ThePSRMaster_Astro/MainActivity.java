package com.ThePSRMaster_Astro;

import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

import com.ThePSRMaster_Astro.R;
//import android.R;
//import java.lang.Object;

//import com.example.psrmaster.MainActivity.ButtonListener;

//import com.example.pressme.MainActivity.ButtonListener;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
//import android.content.Intent;
import android.graphics.Color;
import android.text.format.Time;
//import android.text.Html;
//import android.view.Menu;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
//import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.ProgressBar;
//import android.widget.TimePicker;
//import    java.text.SimpleDateFormat;

//SimpleDateFormat formatte=new SimpleDateFormat("ss");
//Calendar c = Calendar.getInstance();



public class MainActivity extends Activity {
public boolean supernova=false;
public ImageButton btnready;
public ImageButton btnscissor;
public ImageButton btnrock;
public ImageButton btnpaper;
public TextView txt;
//public boolean overornot=false;
public ImageView imagerobot;
public ImageView imageplayer;
public ImageView robotwhat;
public ImageView playerwhat;
public ProgressBar bar1;
public ProgressBar bar2;
public TextView playername;
public TextView enemyname;
//ProgressBar 
Random random=new Random();

public int diaosi=0;//1˵�����ǌ�˿��-1˵��������ǌ�˿
public int nixi=0;//1˵��������Ϯ�ˣ�-1˵�����������Ϯ��
public int tSec=0;
public boolean flagstart=false;
boolean slowornot=false;
public int i=1;
public int enemy;
public boolean readyornot=false;
//public int NUM=50;//the number of total round
public int mydecision=0;//0,1,2 the computer's decision 0,1,2
public int youmoved=0;//0 haven't move, 1 moved. it should be turn to 0 at beginning of each round. 
public int yourdecision=0;//the player's decision 0,1,2
public int foolishness=1;//������Ĵ�ɵ�ӵȼ�
public int strategy[][]={{1,0,2},{2,2,2},{0,2,1},{1,1,1},{2,1,0},{0,0,0}};
public int result=0;//tie 0; 1, computer win; 2, player win
public int lianbai=0;
public int liansheng=0;
//public int wozhong=0;
//public int nizhong=0;
public int wise=0;
public int rotate=0;
public int previous=0;//player's previous move.
public int myblood=50;//computer's score
public int yourblood=50;//player's score
public int randomness=0;
public int wiseness=0;
public int naiveness=0;
public int tough=0;
public int[] rotation=new int[8];
public int correlation=0;
public int pattern=0;
public int Iguess=0;
public int k=0;
public int best=3;
//public boolean userpress=true;
public int period=0;//this is the period of the pattern.
public int disapper=0;//this is a flag of the disappear of the pattern.
public int[] shift=new int[8];
Timer timer=new Timer();
protected void onCreate(Bundle savedInstanceState) {
	Intent intent=getIntent();
	//Bundle bundle = getIntent().getExtras();
	//getIntent().getIntExtra("PLAYERMOVES", 0);
	//int enemy=bundle.getInt("enemy");
	enemy=intent.getIntExtra("enemy", 1);
	super.onCreate(savedInstanceState);

	setContentView(R.layout.activity_main);
	btnready=(ImageButton)findViewById(R.id.imageButton1);
	btnscissor=(ImageButton)findViewById(R.id.imageButton2);
	btnrock=(ImageButton)findViewById(R.id.imageButton3);
	btnpaper=(ImageButton)findViewById(R.id.imageButton4);
	playername=(TextView)findViewById(R.id.textView3);
	enemyname=(TextView)findViewById(R.id.textView2);
	txt=(TextView)findViewById(R.id.textView1);
	txt.setTextColor(Color.argb(255,255,0,0));
	enemyname.setTextColor(Color.argb(255,0,255,0));
	playername.setTextColor(Color.argb(255,0,255,0));
	timer.schedule(timerTask,0,100);
	bar1=(ProgressBar)findViewById(R.id.progressBar1);
	bar2=(ProgressBar)findViewById(R.id.progressBar2);
	imagerobot=(ImageView)findViewById(R.id.imageView1);
	imageplayer=(ImageView)findViewById(R.id.imageView2);
	robotwhat=(ImageView)findViewById(R.id.imageView3);
	playerwhat=(ImageView)findViewById(R.id.imageView4);
	
	ButtonListener btnReadyListener=new ButtonListener();
	ButtonListener btnDoListener=new ButtonListener();
	
	switch(enemy){
	case 1:{enemyname.setText("����");break;}
	case 2:{enemyname.setText("��˹");break;}
	case 3:{enemyname.setText("Ǯ����");break;}
	case 4:{enemyname.setText("������");break;}
	case 5:{enemyname.setText("����а��");break;}
	default:break;
}
	btnready.setOnTouchListener(btnReadyListener);
	btnscissor.setOnClickListener(btnDoListener);
	btnrock.setOnClickListener(btnDoListener);
	btnpaper.setOnClickListener(btnDoListener);
	
}//end of oncreat


public boolean computersmove(int i){
	Time time=new Time();
	Random random=new Random();
	if (i==1) {time.setToNow();mydecision=time.second%3;} 
	else if (i<=5 && i>1) {if (result==1) mydecision=(mydecision-1+3)%3;else mydecision=(mydecision-1+3)%3;}
		//mydecision=random.nextInt(3);//initial move is random, from 0 to 2.
	else if(pattern==1);
	else switch (wise){
	case 0:{mydecision=(mydecision+strategy[foolishness][result])%3;break;}
	case 1:{if(tough==0) mydecision=random.nextInt(3); else mydecision=(mydecision+strategy[foolishness][result]+2)%3; break;}
	case 2:{mydecision=(mydecision+strategy[foolishness][result])%3;break;}
	default:break;
	}
	
	//looking for periodic structure
	if (i<8) rotation[i]=rotate-1;//this minus one is important, to make rotation=-1,0,1
	else {for (int l=0;l<=6;l++) {rotation[l]=rotation[l+1];} rotation[7]=rotate-1;}//moving window
	k=0;
	correlation=0;
	best=3;
	while (k<=4) {k++;correlation=0;
   	for (int j=0;j<=7-k;j++){shift[j]=rotation[k+j];
	}
	for (int j=1;j<=k;j++){shift[7-k+j]=rotation[7-k+j];
	}
	for (int l=0;l<8;l++) {//cout<<rotation[l]<<"*"<<shift[l]<<endl;
		correlation+=rotation[l]*shift[l];
		}
	     // cout<<"k="<<k<<" correlation="<<correlation<<endl;
	if (correlation>best) {best=correlation;period=k;}
	else;
			}

	if (best>3) {pattern=1;foolishness=-1;}//cout<<"correlation="<<correlation<<endl;}
	else pattern=0;
	if (pattern==1) {Iguess=rotation[8-period]+1;mydecision=(3-previous-Iguess+1)%3;}//this plus 1 is crucial
	else;
	if (diaosi==1) {time.setToNow();mydecision=time.second%3;}//if you loss too much, then use random!!
	else;
//unveil the computer's decision			
	if (flagstart){
		switch (mydecision){
		case 0:{robotwhat.setImageResource(R.drawable.paper_trans);break;}
		case 1:{robotwhat.setImageResource(R.drawable.scissor_transp);break;}
		case 2:{robotwhat.setImageResource(R.drawable.rock_transp);break;}
		}}
	else;
	
///////my decision is over//////////////////////////////
	return false;
	}//end of the function "thecomputer's move"

public boolean resultevalue(int mydecision,int yourdecision,boolean slowornot){

	if (slowornot==true) result=1;
	else {rotate=(3+yourdecision-previous)%3;
		result=(mydecision+yourdecision+3)%3; 
		//txt.setText(String.valueOf(result));
		}
	switch (result){//judge from previous result;
		case 0 : {switch (rotate){
				case 0 : {foolishness=0;break;}
				case 1 : {foolishness=2;break;}
				case 2 : {foolishness=1;break;}
				default : break;};break;}
		case 1 : {switch (rotate){
                        case 0 : {foolishness=5;break;}
                        case 1 : {foolishness=1;break;}
                        case 2 : {foolishness=3;break;}
                        default : break;};break;}
		case 2 : {switch (rotate){
                        case 0 : {foolishness=1;break;}
                        case 1 : {foolishness=2;break;}
                        case 2 : {foolishness=4;break;}
                        default : break;};break;}
		default:break;}//end of switch
	

//pattern recognise  or mymove given here
//	
	//cout<<"rotation="<<rotate-1<<endl;
	previous=yourdecision;

	if ((pattern==1)&&(result!=1)) {for (int j=0;j<=7;j++) rotation[j]=0; pattern=0;period=0;} //pattern disappear;
	else ;
	switch (result){
	case 0:{ txt.setText("ƽ�֣�");liansheng=0;imageplayer.setImageResource(R.drawable.profile);imagerobot.setImageResource(R.drawable.androidrobot_normal);break;}
	
	case 1:{if (slowornot==true) txt.setText("̫����");
	else txt.setText("��������");yourblood--;lianbai=0;liansheng++;imageplayer.setImageResource(R.drawable.baozha);imagerobot.setImageResource(R.drawable.androidrobot_normal); break;}
	//case -2:{txt.setText("��Ӯ�ˣ���̫����");myscore++;break;}
	case 2:{txt.setText("���������");myblood--;lianbai++;liansheng=0;imagerobot.setImageResource(R.drawable.baozha);imageplayer.setImageResource(R.drawable.profile);break;}
	//case -1:{txt.setText("��Ӯ�ˣ��ɵĺã�");yourscore++;break;}
	default : break;}
	

	if (yourblood-myblood>10) diaosi=1;
	else diaosi=0;
//���ݲ�ͬ�ĵ���ѡ��ͬ��ģʽ
	switch(enemy){
	case 1:{if (i%5==0) yourblood=yourblood-50/yourblood;break;}//Hawking evaporation
	case 2:{if (liansheng>1){ txt.setText("��������!");yourblood=(int) (yourblood+1-Math.round(Math.pow(2,liansheng-1)));}break;}//inflation
	case 3:{if ((double)yourblood/(double)myblood>1.4 && supernova==false) {txt.setText("�����Ǳ�����");myblood=yourblood;supernova=true;};break;}//supernova
	case 4:{if ((double)yourblood/(double)myblood>2)yourblood--;break;}//Endington limit
	default:break;}
	bar1.setProgress(myblood);
//	bar1.setProgress(10);
	bar2.setProgress(yourblood);
	
	if (myblood<=0||yourblood<=0) {//game over
		//	overornot=true;
			if (myblood<=0){
				if (yourblood>=30) {txt.setText("����ϵ��");robotwhat.setImageResource(R.drawable.shuxu);}
				else if((yourblood>=20) && (yourblood<30)) {txt.setText("��ţ�����С��һ��"); robotwhat.setImageResource(R.drawable.koutaw);}
				else if (yourblood>=10 && yourblood <20) {txt.setText("����ĺܻ��氡��");robotwhat.setImageResource(R.drawable.fanwei);}
				else {txt.setText("��ʤ�ú��գ�");robotwhat.setImageResource(R.drawable.robot_man_shakehand);}
			}
			else if (yourblood<=0){
				if (myblood>=30) {txt.setText("�ò����ˣ�");robotwhat.setImageResource(R.drawable.medecine);}
				else if (myblood>=20 && myblood <30) {txt.setText("���ɵ������");robotwhat.setImageResource(R.drawable.yaoming);}
				else if (myblood>=10 && myblood <20) {txt.setText("�����˼���ѿ��ƣ�");robotwhat.setImageResource(R.drawable.wantyou);}
				else {txt.setText("���ó��ã�");robotwhat.setImageResource(R.drawable.robot_man_shakehand);}
				//someone die, reset the number of rounds;
			}}
	return false;
	}
class ButtonListener implements OnClickListener, OnTouchListener{
	public boolean onTouch(View v, MotionEvent event){
		if(v.getId()==R.id.imageButton1){
			if(event.getAction()==MotionEvent.ACTION_UP){
				
				tSec=0;
				flagstart=true;
				btnready.setImageResource(R.drawable.yellowbutton);
				computersmove(i);
			//	if (myblood==0||yourblood==0) i=0;//someone die, reset the number of rounds;
				txt.setText(" ");
				youmoved=1;
				return true;
			}
			if(event.getAction()==MotionEvent.ACTION_DOWN){
				if (myblood==0||yourblood==0) {//game over
				//	overornot=true;
				//	if (myblood==0){
				//		if (yourblood>=18) {txt.setText("����ϵ��");robotwhat.setImageResource(R.drawable.profile);}
				//		else if((yourblood>=12) && (yourblood<18)) {txt.setText("��ţ�����С��һ��"); robotwhat.setImageResource(R.drawable.koutaw);}
				//		else if (yourblood>=8 && yourblood <12) {txt.setText("����ĺܻ��氡��");robotwhat.setImageResource(R.drawable.fanwei);}
				//		else {txt.setText("��ʤ�ú��գ�");robotwhat.setImageResource(R.drawable.robot_man_shakehand);}
				//	}
				//	else if (yourblood==0){
				//		if (myblood>=18) {txt.setText("�ò����ˣ�");robotwhat.setImageResource(R.drawable.medecine);}
				//		else if (myblood>=12 && myblood <18) {txt.setText("���ɵ������");robotwhat.setImageResource(R.drawable.yaoming);}
				//		else if (myblood>=8 && myblood <12) {txt.setText("�����˼���ѿ��ƣ�");robotwhat.setImageResource(R.drawable.wantyou);}
				//		else {txt.setText("���ó��ã�");robotwhat.setImageResource(R.drawable.robot_man_shakehand);}
						//someone die, reset the number of rounds;
					//}
					
					i=1;
					myblood=50;
					yourblood=50;
					supernova=false;
				}
				
				else i++;
				btnready.setImageResource(R.drawable.green);
				robotwhat.setImageResource(R.drawable.ic_launcher);
				playerwhat.setImageResource(R.drawable.profile);
			//	comments.setText(" ");
				txt.setText(" ");
				youmoved=0;
				readyornot=true;
		return true;
		}
	return false;	
	}
		return true;}
	
	public  void onClick(View v){
		if (readyornot==false) txt.setText("��Ҫ�Ȱ�ס�����Ǽ�");
		else if (youmoved==0) txt.setText("��Ҫ̧�����������");
		else if (i>1){
		switch (v.getId()){
		case R.id.imageButton2:{yourdecision=2;youmoved=0;playerwhat.setImageResource(R.drawable.scissor_transp);break;}
		case R.id.imageButton3:{yourdecision=1;youmoved=0;playerwhat.setImageResource(R.drawable.rock_transp);break;}
		case R.id.imageButton4:{yourdecision=0;youmoved=0;playerwhat.setImageResource(R.drawable.paper_trans);break;}
		default: break;}
	//	if(youmoved==0){
		if (myblood==0||yourblood==0)  btnready.setImageResource(R.drawable.red); 
		//}
				
		flagstart=false;
		readyornot=false;
		if(tSec>4) slowornot=true;
		else slowornot=false;
		resultevalue(mydecision,yourdecision,slowornot);
		}
		else;}
	}


		


	
	
	
	
	
	
		private TimerTask timerTask=new TimerTask(){	
			public void run(){
				if(flagstart) tSec++;
				else;}
		}
;}	
		
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

