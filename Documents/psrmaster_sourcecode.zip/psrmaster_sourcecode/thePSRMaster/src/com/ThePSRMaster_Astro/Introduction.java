package com.ThePSRMaster_Astro;

import com.ThePSRMaster_Astro.R;

import android.app.Activity;
import android.content.Intent;
//import android.content.Intent;
import android.os.Bundle;
//import android.view.View;
import android.view.KeyEvent;

public class Introduction extends Activity {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
	super.onCreate(savedInstanceState);
	setContentView(R.layout.introduction);
	//Button buttonw1;
	}
	public boolean onKeydown(int keyCode,KeyEvent event){
		if(keyCode==KeyEvent.KEYCODE_BACK){startActivity(new Intent(getApplicationContext(), Welcome.class));}
		else;
		return true;
	}

}
