package com.ThePSRMaster_Astro;

import com.ThePSRMaster_Astro.R;

import android.app.Activity;
import android.content.Intent;
//import android.content.Intent;
//import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
//import android.view.View;
//import android.view.KeyEvent;
import android.widget.Button;

public class Selection extends Activity {
	public Button Sunyaev;
	public Button Hawking;
	public Button Guthe;
	public Button Chandra;
	public Button Endinton;
	public int selection;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		final Intent i=new Intent(getApplicationContext(),MainActivity.class);
		
		super.onCreate(savedInstanceState);
		setContentView(R.layout.selection);
	Sunyaev=(Button)findViewById(R.id.button5);
	Hawking=(Button)findViewById(R.id.button1);
	Guthe=(Button)findViewById(R.id.button2);
	Chandra=(Button)findViewById(R.id.button3);
	Endinton=(Button)findViewById(R.id.button4);
     

	Sunyaev.setOnClickListener(new OnClickListener() {            
        public void onClick(View v) {
        	selection=5;
        	i.putExtra("enemy",5);
            //startActivity(new Intent(getApplicationContext(), MainActivity.class));
        	startActivity(i);
        }
    });
	Hawking.setOnClickListener(new OnClickListener() {            
        public void onClick(View v) {
        	selection=1;
        	i.putExtra("enemy", 1);
        	startActivity(i);
            //startActivity(new Intent(getApplicationContext(), MainActivity.class));
        }
    });
	Guthe.setOnClickListener(new OnClickListener() {            
        public void onClick(View v) {
        	selection=2;
        	i.putExtra("enemy", 2);
        	startActivity(i);
            //startActivity(new Intent(getApplicationContext(), MainActivity.class));
        }
    });
	Chandra.setOnClickListener(new OnClickListener() {            
        public void onClick(View v) {
        	selection=3;
        	i.putExtra("enemy", 3);
        	startActivity(i);
       //     startActivity(new Intent(getApplicationContext(), MainActivity.class));
        }
    });
	Endinton.setOnClickListener(new OnClickListener() {            
        public void onClick(View v) {
        	selection=4;
        	i.putExtra("enemy", 4);
        	startActivity(i);
       //     startActivity(new Intent(getApplicationContext(), MainActivity.class));
        }
    });
	

	
	
	
	}

}
