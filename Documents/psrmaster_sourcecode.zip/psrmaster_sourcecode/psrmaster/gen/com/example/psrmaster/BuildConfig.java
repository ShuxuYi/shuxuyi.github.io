/** Automatically generated file. DO NOT MODIFY */
package com.example.psrmaster;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}